namespace KebapStore {
    
    export enum IngredientType {

        Salat,
        Soße,
        Zwiebel,
        Tomate,
        Rotkraut

    }
}