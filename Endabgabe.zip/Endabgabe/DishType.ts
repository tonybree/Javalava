namespace KebapStore {
    
    export enum DishType {

        Falafel,
        Döner,
        Yufka
    }
}