namespace KebapStore {
    
    export enum IngredientPositionType {

        Front,
        Back
    }
}