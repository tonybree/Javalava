namespace KebapStore {
    
    export enum Task {

        Cook,
        Prepare,
        Hand
    }
}